<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css\bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/header.css">
        <title>Header</title>
        
    </head>
        <body>
       <!-------------------------Starting of header--------------------------------->
       <header id="header"> 
                <div class="top-header">
                    <div class="container-fluid">
                        <div class="row bg-primary">
                            <div class="col-md-3">
                                <div class="one text-white list-unstyled ml-3"><i class="fa fa-phone"></i> &nbsp;9843494463 / 9823572911 </div>
                            </div>
                            <div class="col-md-3">
                                <div class="one list-unstyled"> <i class="fa fa-envelope text-white"></i> <a href="#" > info@xyz.com</a></div>
                              </div>
                              <div class="col-md-3">
                                </div>
                                <div class="col-md-3">
                                  </div>
                              </div>
                        </div>
                    </div>
                </div> 
              </header>
       <!-----------------------------End of Header--------------------------------->


      <!------------------Start of navbar--------------------------------------------->
              
                <nav class="navbar  navbar-expand-lg navbar-light top-navbar bg-light sticky-top">
                        <a class="navbar-brand" href="#"><img src="images/a.jpg"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" 
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" 
                        aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                              </button>
                            
                      
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav ml-5">
                            <li class="nav-item">
                              <a class="nav-link mr-2" href="#">Home </a>
                            </li>
                            <li class="nav-item"> 
                              <a class="nav-link mr-2" href="about.php">About Us</a>
                            </li>
                            <li class="nav-item dropdown mr-2">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Study Abroad
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                      <a class="dropdown-item" href="#">Study in USA</a>
                                      <a class="dropdown-item" href="#">Study in UK</a>
                                      <a class="dropdown-item" href="#">Study in Australia</a>
                                      <a class="dropdown-item" href="#">Study in Japan</a>
                                      
                                    </div>
                                  </li>
                            <li class="nav-item">
                                <a class="nav-link mr-2" href="#">Services</a>
                            </li>
                            <li class="nav-item">
                                 <a class="nav-link mr-2" href="#">Events</a>
                             </li>
                             <li class="nav-item">
                                    <a class="nav-link" href="#">Contact</a>
                                </li>
                          </ul>
                          
                        </div>
                      </nav>
                    
                      <!---------------------------End of navbar--------------------------->
 


                      <script src="js\jquery-3.4.1.min.js"></script>
            <script src="js\bootstrap.js"></script>
            
        </body>
</html>
