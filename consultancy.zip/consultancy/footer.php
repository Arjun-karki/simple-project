<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="css\bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/footer.css">
        <title>Footer</title>
    </head>
    
        <body>
             <!----------------Start of Footer---------------------->

             <footer id="footer">
              <div class="container-fluid">
              <div class="row bg-primary"> <!---------------start of first footer----------- -->
              <div class="col-md-3 footerimage  text-white col-sm-3" >
                  <a  href="#"><img src="images/a.jpg" class="img-fluid"></a>
                  <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit xufjsdkjd
                       </p>
              </div>
              <div class="col-md-3  text-white my-3 col-sm-3 quicklinks">
                <h5>Quick Links</h5>
                <ul class="list-unstyled ">
                  <li> <i class="fa fa-long-arrow-right"></i> <a href="#">Study in Australia</a></li>
                  <li> <i class="fa fa-long-arrow-right"></i> <a href="#"> Study in Japan</a></li>
                  <li>  <i class="fa fa-long-arrow-right"></i> <a href="#"> Study in USA</a></li>
                  <li> <i class="fa fa-long-arrow-right"></i> <a href="#">  Study in Uk</a></li>
                </ul>
              </div>

              <div class="col-md-3 my-3 text-white col-sm-3 contactus">
                <h5>Contact Us</h5>
                <ul class="list-unstyled">
                  <li>Location : Tinkune, Kathmandu </li>
                  <li>Email : <a href="#">info@xyz.com</a></li>
                  <li>Contact No : 9941010101</li>
                </ul>
              </div>

              <div class="col-md-3 text-white my-3 col-sm-3 followus">
                <h5>Follow Us: </h5>
                <a href="#"> <i class="fa fa-facebook-f fa-2x  mr-2 my-2 "></i> </a>
                <a href="#"> <i class="fa fa-instagram fa-2x  mr-2 my-2 2"></i> </a>
                <a href="#"> <i class="fa fa-twitter fa-2x  mr-2 my-2 3"></i> </a>
                <a href="#"> <i class="fa fa-youtube fa-2x  my-2 4"></i> </a>

              </div>
              </div> <!-------------------end of first footer--------------->

              <!---------------start of last footer-------------- -->

              <div class="row bg-primary mt-1 text-white lastfooter">
                <div class="col-md-12 text-center">
                  <p class="zero">
                <p class="one"> Copyright &copy; All rights reserved by: <a href="#"> xyz.com</a></p>
                <p class="two"> Designed & Developed by: <a href="#"> Arjun Karki</a></p>
                  </p>
              </div> 
            </div>
              </div> <!----------------end of last footer------------->
            </footer>
            <!----------End of entire footer------------------>


            <script src="js\jquery-3.4.1.min.js"></script>
            <script src="js\bootstrap.js"></script>
            
        </body>
</html>